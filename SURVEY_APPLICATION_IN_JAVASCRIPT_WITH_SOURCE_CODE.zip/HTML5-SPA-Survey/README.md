# HTML5-SPA-Survey

Introduction:

This is a small HTML5 Survey Single Page Application (SPA) which applies CRUD, this application is using HTML5s local storage to store the data in JSON format  

The code is pretty straightforward which uses the plain Javascript and JQuery in some cases


This application is tested in desktop Chrome, Firefox, and Edge browsers successfully.   

This application is tested in Mobile browsers successfully.  

About the survey: 

This application captures the details about a person such as a Name, DOB, Children details, Annual Salary, 2 Wheeler details, 4 wheeler details and their insurance renewal dates, personal insurance renewal dates.   


Technical Details:  Mainly uses Javascript, JQuery and Bootstrap.

